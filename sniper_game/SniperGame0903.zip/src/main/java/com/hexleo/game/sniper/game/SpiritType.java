package com.hexleo.game.sniper.game;

/**
 * Created by hexleo on 2017/8/27.
 */

public interface SpiritType {
    int SNIPER = 1;
    int ENEMY = 2;
    int BULLET = 3;
    int TIME = 4;
}
