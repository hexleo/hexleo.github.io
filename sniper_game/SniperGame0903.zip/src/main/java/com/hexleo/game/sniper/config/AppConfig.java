package com.hexleo.game.sniper.config;

/**
 * Created by hexleowang on 2017/9/2.
 */

public class AppConfig {
    public static final boolean DEBUG = true;
}
