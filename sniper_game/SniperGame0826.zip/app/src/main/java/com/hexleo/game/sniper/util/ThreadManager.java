package com.hexleo.game.sniper.util;

import android.os.Handler;
import android.os.Looper;

/**
 * Created by hexleo on 2017/8/23.
 */

public class ThreadManager {

    private static Handler mainHandler = new Handler(Looper.getMainLooper());

    public static Handler getMainHandler() {
        return mainHandler;
    }

}
