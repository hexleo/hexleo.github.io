package com.hexleo.game.sniper.game;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hexleo.game.sniper.engine.Scene;
import com.hexleo.game.sniper.engine.Spirit;
import com.hexleo.game.sniper.util.DensityUtil;


/**
 * Created by hexleo on 2017/8/22.
 */

public class HandlerSpirit extends Spirit {

    public static final int TYPE = 2;

    private Paint paint;
    private float size = DensityUtil.dp2px(10);
    private float stroke = DensityUtil.dp2px(1);
    private int event = HandlerEventState.EVENT_UP;
    public float startX = 0, startY = 0, endX = 0, endY = 0;

    public HandlerSpirit(Scene scene) {
        super(scene);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(0xff808080);
        paint.setStrokeWidth(stroke);
    }



    @Override
    public boolean isFinish() {
        return false;
    }

    @Override
    public void move() {

    }

    @Override
    public void action() {
        HandlerEventState eventState = ((GameScene)getScene()).getEventState();
        event = eventState.getEvent();
        startX = eventState.startX;
        startY = eventState.startY;
        endX = eventState.endX;
        endY = eventState.endY;
    }

    @Override
    public int getType() {
        return TYPE;
    }

    @Override
    public void draw(Canvas canvas) {
        if (event == HandlerEventState.EVENT_MOVE) {
            canvas.drawCircle(startX, startY, size, paint);
            canvas.drawLine(startX, startY, endX, endY, paint);
            canvas.drawCircle(endX, endY, size, paint);
        }
    }
}
