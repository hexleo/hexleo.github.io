package com.hexleo.game.sniper;

import com.hexleo.game.sniper.engine.Effect;
import com.hexleo.game.sniper.game.GameManager;
import com.hexleo.game.sniper.log.SLog;
import com.hexleo.game.sniper.util.ThreadManager;

/**
 * Created by Administrator on 2017/8/20.
 */

public class GameEffect implements Effect {

    private static final String TAG = "GameEffect";
    private EffectListener effectListener;

    public void setEffectListener(EffectListener effectListener) {
        this.effectListener = effectListener;
    }

    public void killed() {
        SLog.d(TAG, "killed");
        if (effectListener != null) {
            ThreadManager.getMainHandler().post(new Runnable() {
                @Override
                public void run() {
                    effectListener.onEnemyKilled(GameManager.getInstance().getScore().getKillNum());
                }
            });
        }
    }

    public interface EffectListener {
        void onEnemyKilled(int num);
    }
}
