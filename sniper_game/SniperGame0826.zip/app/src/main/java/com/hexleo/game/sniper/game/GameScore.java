package com.hexleo.game.sniper.game;

import android.os.SystemClock;

/**
 * Created by hexleo on 2017/8/25.
 */

public class GameScore {

    private long playTime;
    private int killNum;

    public void play() {
        playTime = SystemClock.uptimeMillis();
        killNum = 0;
    }

    public int getKillNum() {
        return killNum;
    }
}
