package com.hexleo.game.sniper.view;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.hexleo.game.sniper.GameEffect;
import com.hexleo.game.sniper.R;
import com.hexleo.game.sniper.game.GameConfig;
import com.hexleo.game.sniper.game.GameManager;
import com.hexleo.game.sniper.game.GameScene;

/**
 * Created by hexleo on 2017/8/26.
 */

public class InfoView extends FrameLayout {
    private View mRoot;
    private View mMenu;
    private TextView mEnemyKillCount;
    private MenuListener menuListener;
    private AnimatorSet killedAnimator;
    private OnClickListener listener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            GameScene scene = GameManager.getInstance().getScene();
            switch (v.getId()) {
                case R.id.easy_btn:
                    scene.setGameLevel(GameConfig.Level.EASY);
                    break;
                case R.id.normal_btn:
                    scene.setGameLevel(GameConfig.Level.NORMAL);
                    break;
                case R.id.hard_btn:
                    scene.setGameLevel(GameConfig.Level.HARD);
                    break;
            }
            mMenu.setVisibility(GONE);
            if (menuListener != null) {
                menuListener.onMenuSelected();
            }
        }
    };
    private GameEffect.EffectListener effectListener = new GameEffect.EffectListener() {
        @Override
        public void onEnemyKilled(int num) {
            if (killedAnimator == null) {
                ObjectAnimator sX = ObjectAnimator.ofFloat(mEnemyKillCount, "scaleX", 1f, 1.2f, 1f);
                ObjectAnimator sY = ObjectAnimator.ofFloat(mEnemyKillCount, "scaleY", 1f, 1.2f, 1f);
                killedAnimator = new AnimatorSet();
                killedAnimator.playTogether(sX, sY);
                killedAnimator.setDuration(200);
            }
            if (killedAnimator.isRunning()) {
                killedAnimator.cancel();
            }
            mEnemyKillCount.setVisibility(VISIBLE);
            mEnemyKillCount.setText("Kill x" + num);
            killedAnimator.start();
        }
    };

    public InfoView(Context context) {
        super(context);
        init(context);
    }


    public InfoView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        mRoot = LayoutInflater.from(context).inflate(R.layout.info_view, this, true);
        mMenu = mRoot.findViewById(R.id.menu);
        mEnemyKillCount = (TextView) mRoot.findViewById(R.id.killed_count);
        Button easyButton = (Button) mRoot.findViewById(R.id.easy_btn);
        Button normalButton = (Button) mRoot.findViewById(R.id.normal_btn);
        Button hardButton = (Button) mRoot.findViewById(R.id.hard_btn);
        easyButton.setOnClickListener(listener);
        normalButton.setOnClickListener(listener);
        hardButton.setOnClickListener(listener);
        GameManager.getInstance().getEffect().setEffectListener(effectListener);
    }

    public void showMenu(MenuListener listener) {
        mMenu.setVisibility(VISIBLE);
        menuListener = listener;
        mEnemyKillCount.setVisibility(GONE);
    }

    public interface MenuListener {
        void onMenuSelected();
    }

}
