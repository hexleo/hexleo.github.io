package com.hexleo.game.sniper.activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;

import com.hexleo.game.sniper.R;
import com.hexleo.game.sniper.game.GameManager;
import com.hexleo.game.sniper.game.GameScene;
import com.hexleo.game.sniper.game.SniperSpirit;
import com.hexleo.game.sniper.util.ThreadManager;
import com.hexleo.game.sniper.view.GameTextureView;
import com.hexleo.game.sniper.view.InfoView;

public class MainActivity extends Activity {

    private GameTextureView gameView;
    private InfoView infoView;

    private GameScene.SceneListener sceneListener = new GameScene.SceneListener() {

        @Override
        public void onGameStart() {
            ThreadManager.getMainHandler().post(new Runnable() {
                @Override
                public void run() {
                    infoView.showScore();
                }
            });
        }

        @Override
        public void onGameOver() {
            ThreadManager.getMainHandler().post(new Runnable() {
                @Override
                public void run() {
                    infoView.showMenu();
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gameView = (GameTextureView) findViewById(R.id.game);
        infoView = (InfoView) findViewById(R.id.info_view);
        infoView.showMenu();
        GameManager.getInstance().getScene().setSceneListener(sceneListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        GameManager.getInstance().getScene().resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        GameManager.getInstance().getScene().pause();
    }

}
