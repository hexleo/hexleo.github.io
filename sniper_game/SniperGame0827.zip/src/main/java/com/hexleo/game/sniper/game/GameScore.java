package com.hexleo.game.sniper.game;

import android.os.SystemClock;

import com.hexleo.game.sniper.log.SLog;

/**
 * Created by hexleo on 2017/8/25.
 */

public class GameScore {
    private static final String TAG = "GameScore";

    public static final long COMBO_GAP = 5000;
    private static final int MAX_COMBO = 4;

    private long playTime;
    private long lastKillTime;
    private int killNum;
    private int score;
    private int combo;

    public void reset() {
        playTime = 0;
        lastKillTime = 0;
        killNum = 0;
        score = 0;
        combo = 0;
    }

    public void play(long time) {
        reset();
        playTime = time;
    }

    public void addKill() {
        score++;
        killNum++;
        long time = GameManager.getInstance().getScene().getTime();
        if (time - lastKillTime <= COMBO_GAP) {
            combo++;
            combo = combo > MAX_COMBO ? MAX_COMBO : combo;
        } else {
            combo = 0;
        }
        score += combo;
        lastKillTime = time;
    }

    public int getKillNum() {
        return killNum;
    }

    public int getScore() {
        return score;
    }

    public int getCombo() {
        return combo;
    }

    public long getPlayTime() {
        long time = GameManager.getInstance().getScene().getTime();
        return (time - playTime) / 1000;
    }

}
