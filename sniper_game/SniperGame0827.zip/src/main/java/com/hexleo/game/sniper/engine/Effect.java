package com.hexleo.game.sniper.engine;

/**
 * effect like sound
 * Created by hexleo on 2017/8/20.
 */

public interface Effect {
}
