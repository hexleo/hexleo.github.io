package com.hexleo.game.sniper.game;

import android.os.SystemClock;

import com.hexleo.game.sniper.engine.Scene;
import com.hexleo.game.sniper.log.SLog;

/**
 * Created by hexleo on 2017/8/20.
 */

public class GameScene extends Scene {
    private static final String TAG = "GameManager";

    private HandlerEventState eventState;
    private SniperSpirit sniperSpirit;
    private int mGameLevel;
    private float[] mEndPoint = new float[2];
    private long mLastTimeCreateEnemy;
    private int mGameRound;
    public SceneListener mSceneListener;


    public GameScene() {
        super();
        eventState = new HandlerEventState();
        mGameLevel = GameConfig.Level.EASY;
    }

    public void setSceneListener(SceneListener sceneListener) {
        this.mSceneListener = sceneListener;
    }

    public void setGameLevel(int level) {
        mGameLevel = level;
        GameManager.getInstance().getConfig().setLevel(level);
    }

    @Override
    public void setSize(int width, int height) {
        super.setSize(width, height);
        mEndPoint[0] = width / 2;
        mEndPoint[1] = height / 2;
    }

    @Override
    public void postWork() {
        super.postWork();
        long time = getTime();
        long appearTime = GameConfig.ENEMY_APPEAR_TIME_GAP - mGameRound * GameConfig.ENEMY_APPEAR_TIME_DE;
        appearTime = appearTime <= 1000 ? 1000 : appearTime;
        if ((time - mLastTimeCreateEnemy) > appearTime) {
            mLastTimeCreateEnemy = time;
            mGameRound++;
            genGame();
        }
        if (sniperSpirit.isCrazy()) {
            createBulletIn();
        }

        if (eventState.canDagger()) {
            createDagger();
        }
    }

    @Override
    public HandlerEventState getEventState() {
        return eventState;
    }

    public void setEndPoint(int x, int y) {
        mEndPoint[0] = x;
        mEndPoint[1] = y;
    }

    public float[] getEndPoint() {
        return mEndPoint;
    }

    private void createBulletIn() {
        addSpirit(new BulletSpirit(this, eventState, BulletSpirit.TYPE_BULLET));
    }

    public void createBullet() {
        addSpiritDelay(new BulletSpirit(this, eventState, BulletSpirit.TYPE_BULLET));
    }

    private void createDagger() {
        addSpirit(new BulletSpirit(this, eventState, BulletSpirit.TYPE_DAGGER));
    }

    public void createGame() {
        clearSpiritList();
        GameManager.getInstance().getScore().play(SystemClock.uptimeMillis());
        mLastTimeCreateEnemy = 0;
        mGameRound = 0;
        sniperSpirit = new SniperSpirit(this);
        addSpirit(sniperSpirit);
        addSpirit(new TimeSpirit(this));
        eventState.reset();
        resume();
    }

    public SniperSpirit getSniperSpirit() {
        return sniperSpirit;
    }

    private void genGame() {
        GameConfig mConfig = GameManager.getInstance().getConfig();
        int num = mConfig.getEnemyCount();
        int[][] role = mConfig.getEnemyRoleAndPattern(num);
        int[][] pos = mConfig.getEnemyPosition(num);
        int[] size = mConfig.getEnemyCount(num);
        float[] speed = mConfig.getEnemySpeed(num);
        EnemySpirit spirit;
        for (int i=0; i<num; i++) {
            spirit = new EnemySpirit(this,role[i][0], role[i][1], size[i], speed[i], pos[i][0], pos[i][1]);
            addSpirit(spirit);
        }
    }

    public void gameOver() {
        pause();
        eventState.reset();
        GameManager.getInstance().gameOver();
        GameManager.getInstance().getEffect().close();
        if (mSceneListener != null) {
            mSceneListener.onGameOver();
        }
    }

    public interface SceneListener {
        void onGameOver();
    }

}
