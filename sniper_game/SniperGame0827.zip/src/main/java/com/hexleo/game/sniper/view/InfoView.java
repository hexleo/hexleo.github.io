package com.hexleo.game.sniper.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.hexleo.game.sniper.GameEffect;
import com.hexleo.game.sniper.R;
import com.hexleo.game.sniper.game.GameConfig;
import com.hexleo.game.sniper.game.GameManager;
import com.hexleo.game.sniper.game.GameScene;
import com.hexleo.game.sniper.game.GameScore;

/**
 * Created by hexleo on 2017/8/26.
 */

public class InfoView extends FrameLayout {
    private View mRoot;
    private View mMenu;
    private View mCombo;
    private View[] mComboStar = new View[4];
    private TextView mEnemyKillCount;
    private MenuListener menuListener;
    private AnimatorSet killedAnimator;
    private AnimatorSet comboAnimator;
    private OnClickListener listener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            GameScene scene = GameManager.getInstance().getScene();
            switch (v.getId()) {
                case R.id.easy_btn:
                    scene.setGameLevel(GameConfig.Level.EASY);
                    break;
                case R.id.normal_btn:
                    scene.setGameLevel(GameConfig.Level.NORMAL);
                    break;
                case R.id.hard_btn:
                    scene.setGameLevel(GameConfig.Level.HARD);
                    break;
            }
            mMenu.setVisibility(GONE);
            if (menuListener != null) {
                menuListener.onMenuSelected();
            }
        }
    };
    private GameEffect.EffectListener effectListener = new GameEffect.EffectListener() {
        @Override
        public void onEnemyKilled() {
            if (killedAnimator == null) {
                ObjectAnimator sX = ObjectAnimator.ofFloat(mEnemyKillCount, "scaleX", 1f, 1.2f, 1f);
                ObjectAnimator sY = ObjectAnimator.ofFloat(mEnemyKillCount, "scaleY", 1f, 1.2f, 1f);
                killedAnimator = new AnimatorSet();
                killedAnimator.playTogether(sX, sY);
                killedAnimator.setDuration(200);
            }
            if (killedAnimator.isRunning()) {
                killedAnimator.cancel();
            }
            mEnemyKillCount.setVisibility(VISIBLE);
            mEnemyKillCount.setText("" + GameManager.getInstance().getScore().getScore());
            killedAnimator.start();

            int combo = GameManager.getInstance().getScore().getCombo();
            if (combo <= 0) {
                return;
            }
            if (comboAnimator == null) {

                ObjectAnimator sX = ObjectAnimator.ofFloat(mCombo, "scaleX", 0.8f, 1.2f, 1f);
                ObjectAnimator sY = ObjectAnimator.ofFloat(mCombo, "scaleY", 0.8f, 1.2f, 1f);
                AnimatorSet scaleSet = new AnimatorSet();
                scaleSet.playTogether(sX, sY);
                scaleSet.setDuration(300);
                ValueAnimator empty = ValueAnimator.ofFloat(0f, 1f);
                empty.setDuration(GameScore.COMBO_GAP - 500);
                ObjectAnimator alpha = ObjectAnimator.ofFloat(mCombo, "alpha", 1f, 0f);
                alpha.setDuration(500);
                comboAnimator = new AnimatorSet();
                comboAnimator.setInterpolator(new LinearInterpolator());
                comboAnimator.playSequentially(scaleSet, empty, alpha);
                comboAnimator.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationStart(Animator animation) {
                        mCombo.setVisibility(VISIBLE);
                        mCombo.setAlpha(1f);
                        int combo = GameManager.getInstance().getScore().getCombo();
                        mComboStar[0].setVisibility(combo >= 1 ? VISIBLE : GONE);
                        mComboStar[1].setVisibility(combo >= 2 ? VISIBLE : GONE);
                        mComboStar[2].setVisibility(combo >= 3 ? VISIBLE : GONE);
                        mComboStar[3].setVisibility(combo >= 4 ? VISIBLE : GONE);
                    }

                    @Override
                    public void onAnimationEnd(Animator animation) {
                        mCombo.setVisibility(GONE);
                    }
                });
            }
            if (comboAnimator.isRunning()) {
                comboAnimator.cancel();
            }
            comboAnimator.start();
        }
    };

    public InfoView(Context context) {
        super(context);
        init(context);
    }


    public InfoView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        mRoot = LayoutInflater.from(context).inflate(R.layout.info_view, this, true);
        mMenu = mRoot.findViewById(R.id.menu);
        mEnemyKillCount = (TextView) mRoot.findViewById(R.id.killed_count);
        mCombo = mRoot.findViewById(R.id.combo);
        mComboStar[0] = mRoot.findViewById(R.id.combo_star_2);
        mComboStar[1] = mRoot.findViewById(R.id.combo_star_3);
        mComboStar[2] = mRoot.findViewById(R.id.combo_star_4);
        mComboStar[3] = mRoot.findViewById(R.id.combo_star_5);

        Button easyButton = (Button) mRoot.findViewById(R.id.easy_btn);
        Button normalButton = (Button) mRoot.findViewById(R.id.normal_btn);
        Button hardButton = (Button) mRoot.findViewById(R.id.hard_btn);
        easyButton.setOnClickListener(listener);
        normalButton.setOnClickListener(listener);
        hardButton.setOnClickListener(listener);
        GameManager.getInstance().getEffect().setEffectListener(effectListener);
    }

    public void showMenu(MenuListener listener) {
        mMenu.setVisibility(VISIBLE);
        menuListener = listener;
        mEnemyKillCount.setVisibility(GONE);
    }

    public interface MenuListener {
        void onMenuSelected();
    }

}
