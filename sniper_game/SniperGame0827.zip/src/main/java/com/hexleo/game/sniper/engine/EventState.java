package com.hexleo.game.sniper.engine;

/**
 * Created by hexleo on 2017/8/20.
 */

public interface EventState {
}
