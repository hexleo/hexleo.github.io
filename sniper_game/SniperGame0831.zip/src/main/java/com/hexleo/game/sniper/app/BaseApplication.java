package com.hexleo.game.sniper.app;

import android.app.Application;

/**
 * Created by hexleo on 2017/8/20.
 */

public class BaseApplication extends Application {

    private static BaseApplication mApp;

    public BaseApplication() {
        mApp = this;
    }

    public static BaseApplication getApp() {
        return mApp;
    }


}
